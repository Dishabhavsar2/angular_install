import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyfirstcomponenetComponent } from './myfirstcomponenet/myfirstcomponenet.component';



@NgModule({
  declarations: [
    MyfirstcomponenetComponent
  ],
  imports: [
    CommonModule
  ]
})
export class MyfirstmoduleModule { }
