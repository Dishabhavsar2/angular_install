import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myfirstcomponenet',
  templateUrl: './myfirstcomponenet.component.html',
  styleUrls: ['./myfirstcomponenet.component.less']
})
export class MyfirstcomponenetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
